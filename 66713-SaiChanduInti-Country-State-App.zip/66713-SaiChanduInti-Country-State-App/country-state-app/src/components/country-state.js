import React, { useState } from 'react';
import { Countries } from '../country-state';


const Home = () => {

    const [state, setState] = useState([]);
    const [result , setResult]= useState(false);
    const [val, setVal]= useState([])

    const renderCountry = () => {
        return Countries.map((country, key) => {
            return (
                <option key={key}>{country.name}</option>
            )

        })
    }

    const handleCountry = (e) => {
        return Countries.map((country, key) => {
            if (e === country.name) {
                setState(country.states)

            }

        })


    }



    const renderState = () => {
        return state.map((value, key) => {
            //console.log(value.name)
            return (
                <option value={value.name} key={key}>{value.name}</option>
            )
        })

    }

    const handleSubmit=(e)=>{
        e.preventDefault()
        
       const country = (e.target.country.value);
       const state = (e.target.state.value);
       if (country){
           setVal([country, state])
           setResult(true)
       }


    }




    return (

        <div>
            <h1>Home</h1>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Country</label>
                    <select name ='country' onClick={(e) => handleCountry(e.target.value)}>Select Country
                        <option disabled>--Select Country</option>
                        {renderCountry()}
                    </select>

                </div>

                <div>
                    <label>State</label>
                    <select name ='state' >Select State
                        <option disabled>---select Country First---</option>
                        {renderState()}



                    </select>

                </div>
                <br />

                <div ><button>Ok</button></div>

            </form>
            <hr/>
            <div >
                {result?' Country= '+val[0] +'  State= '+ val[1]:''}<br/>
            </div>
          
        </div>
    );
};

export default Home;